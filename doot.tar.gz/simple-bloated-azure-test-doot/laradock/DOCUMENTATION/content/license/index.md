---
title: License
type: index
weight: 8
---

[MIT License](https://github.com/laradock/laradock/blob/master/LICENSE) (MIT)
